## Fehlerbeschreibung

## Home-Assistant-Version

## KEW-Smart-Home-OS-Version

## Schritte zum Nachstellen

## Relevante Protokolle
